# BiPolaris Badcase Report

## Summary

- Total cases: 6
- Passed: 6
- Failed: 0
- Average score: 1.0

## Failure Types

- 暂无

## Risk Levels In Badcases

- 暂无

## BD States In Badcases

- 暂无

## LLM Judge Badcase Types

- 暂无

## Representative Examples

No badcases found in this run.
